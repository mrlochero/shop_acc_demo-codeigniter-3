<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '1135903226465690';
$config['secret']  = '18748fa8152ce313838e9145af44e32f';

?>

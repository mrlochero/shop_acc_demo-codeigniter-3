 <!DOCTYPE html>

<html lang="vi">
<!-- Mirrored from php-huyvandnc.rhcloud.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Aug 2016 22:10:18 GMT -->
<head>
    <meta charset="utf-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>SHOPCFRE.COM Chuyên bán các loại acc game giá rẻ</title>
    <meta content=
    "shopcfre.com, shop cf re, shop acc re, shop acc rẻ, shop lien minh, shop liên minh, shop lmht, shop cf, shop dot kich, shop đột kích, dot kich, lien minh huyen thoai, liên minh huyền thoại, lmht, ban acc, bán acc, acc game gia re, acc game giá rẻ, acc lien minh free, acc cf free, share acc cf, share acc lien minh"
    name="keywords">
  <meta content=
    "SHOPCFRE, chuyên bán các loại acc game giá rẻ, Mua acc game giá rẻ tại shopcfre.com "
    name="description">
    <meta content=
    "SHOPCFRE, chuyên bán các loại acc game giá rẻ, Mua acc game giá rẻ tại shopcfre.com "
    name="msvalidate.01">
    <meta content="1135903226465690" property="fb:app_id">
    <meta content="http://shopcfre.com" property="og:url">
    <meta content="vi_VN" property="og:locale">
    <meta content="article" property="og:type">
    <meta content="SHOPCFRE, chuyên bán các loại acc game giá rẻ"
    property="og:title">
    <meta content="http://SHOPCFRE.com/assets/img/maxresdefault.png" property=
    "og:image">
    <meta content=
    "Chuyên bán các loại acc game giá rẻ, Mua acc game giá rẻ tại shopcfre.com "
    property="og:description">
<!-- Web fonts -->
    <link href=
    "http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400italic,600,700%7COpen+Sans:300,400,400italic,600,700"
    rel="stylesheet"><!-- Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/oneui.min-2.2.css" rel="stylesheet">
    <link href="assets/js/slick/slick.min.css" rel="stylesheet">
    <link href="assets/js/slick/slick-theme.min.css" rel="stylesheet">
    <link href="assets/css/core.css" rel="stylesheet">
    <link href="assets/favicon.ico" rel="shortcut icon">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries --><!-- WARNING: Respond.js doesn't work if you view the page via file:// --><!--[if lt IE 9]> <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script> <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script> <![endif]-->
</head>
<body>
   <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.7&appId=1135903226465690";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="float-menu visible-lg-block">
         <div id="float-qr-code"><img alt="" src="assets/img/support.jpg"></div><a class="float-btn" href="https://www.facebook.com/vietdinh284" style="background-image:url(assets/img/bg-float-btn-black.jpg);" target="_blank">FB Đinh Việt</a><a class="float-btn" href="https://www.facebook.com/RyoBlack.Love.Map" style="background-image:url(assets/img/bg-float-btn-black.jpg);" target="_blank">FB Minh Nguyên</a> <a class="float-btn" href="http://shopcfre284.blogspot.com/2016/11/huong-dan-mua-acc-game-tai-shopcfrecom.html" style="background-image:url(assets/img/bg-float-btn-black.jpg);" target="_blank">H&#432;&#7899;ng d&#7851;n mua</a> <a class="float-btn" href="javascript:void(0);" onclick="App.toTop()" style="background-image:url(assets/img/bg-float-btn-black.jpg);">TOP</a>
        <a class="float-show block-notext" href="javascript:void(0);" id="float-hide-btn">&gt;&gt;&gt;</a>
    </div>
  <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button aria-controls="navbar" aria-expanded="false" class=
                "navbar-toggle collapsed" data-target="#navbar" data-toggle=
                "collapse" type="button"><span class="sr-only">Toggle
                navigation</span> <span class="icon-bar"></span> <span class=
                "icon-bar"></span> <span class="icon-bar"></span></button>
                <div class="animbrand">
                    <a class="navbar-brand animate" href="index.php" title=
                    "SHOPCFRE"><img alt="" src=
                    "assets/img/ckc.png"></a>
                </div>
            </div>
            <div class="navbar-collapse collapse" id="navbar">
                <ul class="nav navbar-nav">
									<li>
										<a href=
											 "http://shopcfre284.blogspot.com/2016/11/huong-dan-mua-acc-game-tai-shopcfrecom.html" 
											 target="_blank">Hướng dẫn mua acc game tại shop</a>
									</li>
                    <li>
                        <a href=
                        "https://www.facebook.com/vietdinh284"
                        target="_blank">Liên hệ chủ SHOP</a>
                    </li>
                   
                </ul>
                <ul class="nav navbar-nav navbar-right">
				        <?php if (@$user_profile):  // call var_dump($user_profile) to view all data ?>
					   <li class="dropdown">
					   <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
					   <img class="avatar hidden-xs" src="https://graph.facebook.com/<?=$user_profile['id']?>/picture?type=large" alt="Avatar"> Chào <strong><?=$user_profile['name']?></strong> 
					   <span class="caret"></span></a> <ul class="dropdown-menu"> <li class="dropdown-header">
					   <i class="si si-wallet pull-right"></i><strong class="text-primary"><?=number_format($money, 0, '.', '.')?> <sup class="text-muted">vnđ</sup></strong></li> 
					    <?php if (isset($admin)): ?>
					   <li><a href="javascript:void(0);" id="view-profiles"><i class="fa fa-plus pull-right"></i>Đăng acc</a></li>
					   <?php endif; ?>
					   <li><a href="lichsu"><i class="si si-list pull-right"></i>Lịch sử Giao dịch</a></li> 
					   <li><a href="<?= $logout_url ?>"><i class="si si-logout pull-right"></i>Thoát</a></li> </ul> </li>
					   
       
                                
						<?php else: ?>
						  <li>
                        <a href="<?= $login_url ?>"><span aria-hidden=
                        "true" class="fa fa-facebook-square"></span> Đăng nhập</a>
                    </li><?php endif; ?>
                   
                </ul>
            </div><!--/.nav-collapse -->
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Thống kê</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row items-push">
                            <div class="col-md-3">
                                <div class="text-muted">
                                    <small><i class=
                                    "si si-game-controller"></i> LMHT</small>
                                </div>
                                <div class="font-w600">
                                    <span class="text-danger" data-to="<?=$lienminh?>"
                                    data-toggle="countTo"></span> tài khoản
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="text-muted">
                                    <small><i class=
                                    "si si-game-controller"></i> Đột
                                    Kích</small>
                                </div>
                                <div class="font-w600">
                                    <span class="text-danger" data-to="<?=$dotkich?>"
                                    data-toggle="countTo"></span> tài khoản
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="text-muted">
                                    <small><i class="si si-users"></i> Thành
                                    viên</small>
                                </div>
                                <div class="font-w600">
                                    <span class="text-danger" data-to="<?=$user?>"
                                    data-toggle="countTo"></span> đứa
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="text-muted">
                                    <small><i class="si si-users"></i> Đang
                                    Online</small>
                                </div>
                                <div class="font-w600">
                                    <span class="text-success" data-to="<?=$useronline?>"
                                    data-toggle="countTo"></span> khách,
                                    <span class="text-danger" data-to="<?=$memonline?>"
                                    data-toggle="countTo"></span> thành viên
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Nạp thẻ Ngay Và Luôn</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row text-center">
                            <form id="topup-card" name="topup-card">
                                <div class="col-xs-12 col-md-3">
                                    <div class="form-group">
                                        <label class="sr-only">Số Seri</label>
                                        <input class="form-control input-sm"
                                        id="" name="cardSerial" placeholder=
                                        "Mã serial" type="text">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-3">
                                    <div class="form-group">
                                        <label class="sr-only">Mã thẻ</label>
                                        <input class="form-control input-sm"
                                        id="" name="cardPin" placeholder=
                                        "Mã thẻ" type="text">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-3">
                                    <div class="form-group">
                                        <select class=
                                        "form-control input-sm input-block"
                                        name="telcoCode">
                                            <option value="VTT">
                                                Thẻ Vietel
                                            </option>
                                            <option value="VMS">
                                                Thẻ Mobifone
                                            </option>
                                            <option value="VNP">
                                                Thẻ Vinaphone
                                            </option>
                                            <option value="MGC">
                                                Thẻ Megacard
                                            </option>
                                            <option value="FPT">
                                                Thẻ Gate
                                            </option>
                                            <option value="ZING">
                                                Thẻ ZING
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xs-12 col-md-3">
                                    <div class="form-group">
                                        <button class=
                                        "btn btn-success btn-sm btn-block"
                                        data-loading-text="Đang xử lý..." id=
                                        "btn-topup" type="button">Nạp
                                        luôn</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="block">
            <ul class="nav nav-tabs nav-tabs-alt" data-toggle="tabs">
		 <li class="active">
                    <a href="#cf">Shop Đột Kích</a>
                </li>
                <li >
                    <a href="#lmht">Shop Liên Minh</a>
                </li>
							
            </ul>
             <div class="tab-content">			 
							<div class="block tab-pane active" id="cf">
                    <div class="block-header remove-padding-b">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        Lọc theo Giá
                                    </div><select class=
                                    "js-cfprice-search form-control" id=
                                    "filterbyprice" name="filterbyprice" size=
                                    "1">
                                        <option value="0">
                                            Tất cả
                                        </option>
                                        <option value="1">
                                            Từ 50k trở xuống
                                        </option>
                                        <option value="2">
                                            Từ 50k đến 100k
                                        </option>
                                        <option value="3">
                                            Từ 100k đến 500k
                                        </option>
                                        <option value="4">
                                            Từ 500k đến 1 Triệu
                                        </option>
                                        <option value="5">
                                            Từ 1 Triệu trở lên
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="block-content">
                        <div class="js-cf-list row items-push-2x text-center">
						 <?php foreach($querycf->result() as $row): ?>
                            <div class="col-sm-4 col-md-3 remove-margin-b"
                            data-filter-price="<?=$row->gia?>" >
                                <div class="block clickitem" data-id="<?=$row->id?>">
                                    <div class=
                                    "block-content ribbon ribbon-bookmark ribbon-danger text-center bg-gray-lighter">
									<?php if($row->promo > 0) : ?> <div class="ribbon-box">-<?=$row->promo?>%</div> <?php endif; ?>
                                    <div class="item item-2x bg-crystal-op">
                                        <img alt="" class="img-responsive push"
                                         src="<?php $image = explode("|",$row->hinhanh); echo $image[0];?>" ></div>
                                        <div class="h5 font-w600">
                                            Tài khoản CF #<?=$row->id?>
                                        </div>
                                        <div class="font-s12">
                                            <?=$row->noidung?>
                                        </div>
									
                                        <div class="text-danger font-w600">
										<?php if($row->promo > 0) : ?><span class="text-muted" style="text-decoration: line-through;">
                                           <?=number_format($row->giacu, 0, '.', '.');?></span> <?php endif; ?>
                                            <?=number_format($row->gia, 0, '.', '.');?> <sup class=
                                            "text-muted">vnđ</sup>
                                        </div>
                                    </div>
                                </div>
                            </div>
                          <?php endforeach; ?>
                    
                        </div>
                    </div>
                </div>
                <div class="block tab-pane" id="lmht">
                    <div class="block-header remove-padding-b">
                        <div class="row">
													<div class="col-md-6"> <div class="input-group"> <div class="input-group-addon">Lọc theo Rank</div> <select class="js-rank-search form-control" id="filterbyrank" name="filterbyrank" size="1"> <option value="0">Tất cả</option> <option value="1">Chưa Rank</option> <option value="2">Đồng đoàn</option> <option value="3">Bạc đoàn</option> <option value="4">Vàng đoàn</option> <option value="5">Bạch Kim</option> <option value="6">Kim Cương</option> <option value="7">Cao Thủ</option> <option value="8">Thách Đấu</option> </select>  </div> </div>
                            <div class="col-md-6">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        Lọc theo Giá
                                    </div><select class=
                                    "js-price-search form-control" id=
                                    "filterbyprice" name="filterbyprice" size=
                                    "1">
                                        <option value="0">
                                            Tất cả
                                        </option>
                                        <option value="1">
                                            Từ 50k trở xuống
                                        </option>
                                        <option value="2">
                                            Từ 50k đến 100k
                                        </option>
                                        <option value="3">
                                            Từ 100k đến 500k
                                        </option>
                                        <option value="4">
                                            Từ 500k đến 1 Triệu
                                        </option>
                                        <option value="5">
                                            Từ 1 Triệu trở lên
                                        </option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="block-content">
                        <div class="js-lmht-list row items-push-2x text-center">
						 <?php foreach($querylmht->result() as $row): ?>
                            <div class="col-sm-4 col-md-3 remove-margin-b" data-filter-rank="<?=$row->rank?>"
                            data-filter-price="<?=$row->gia?>">
                                <div class="block clickitem" data-id="<?=$row->id?>">
                                    <div class=
                                    "block-content ribbon ribbon-bookmark ribbon-danger text-center bg-gray-lighter">
									<?php if($row->promo > 0) : ?> <div class="ribbon-box">-<?=$row->promo?>%</div> <?php endif; ?>
                                    <div class="item item-2x bg-crystal-op">
                                        <img alt="" class="img-responsive push"
                                         src="assets/img/rank/base_icons/<?=$row->rank?>.png" ></div>
                                        <div class="h5 font-w600">
                                            Tài khoản LMHT #<?=$row->id?>
                                        </div>
                                        <div class="font-s12">
                                            <?=$row->noidung?>
                                        </div>
																				<div class="font-s12">
                                            <?=$row->thongtin?>
                                        </div>
                                        <div class="text-danger font-w600">
										<?php if($row->promo > 0) : ?><span class="text-muted" style="text-decoration: line-through;">
                                           <?=number_format($row->giacu, 0, '.', '.');?></span> <?php endif; ?>
                                            <?=number_format($row->gia, 0, '.', '.');?> <sup class=
                                            "text-muted">vnđ</sup>
                                        </div>
                                    </div>
                                </div>
                            </div>
													
                          <?php endforeach; ?>
                    
                        </div>
                    </div>
                </div>
				
            </div>
      
        </div>
        <footer class=
        "content-mini content-mini-full font-s12 bg-gray-lighter clearfix" id=
        "page-footer">
            <div class="text-center">
                © <span class="js-year-copy">2016</span> <a class="font-w600"
                href="/">SHOPCFRE</a> | <a class="font-w600"
                href="http://" target="_blank">Shop Acc CF</a>
             
            </div>
            <div class="text-center">
                Crafted with <i class="fa fa-heart text-city"></i> by <a class=
                "font-w600" href="#" target=
                "_blank">maqui189</a>
            </div>
<iframe scrolling="no" width="1080" height="500" src="http://mp3.zing.vn/embed/playlist/IWB0A008?start=true" frameborder="0" allowfullscreen="true"></iframe>
        </footer>
    </div>
    <div class="modal fade" id="requestModal" role="dialog" tabindex="-1">
    </div>
	
    <script src="assets/js/jquery.min.js">
    </script> 
    <script src="assets/js/bootstrap.min.js">
    </script> 
    <script src="assets/js/jquery.slimscroll.min.js">
    </script> 
    <script src="assets/js/bootstrap-notify/bootstrap-notify.min.js">
    </script> 
    <script src="assets/js/bootstrap-show-password.js">
    </script> 
    <script src="assets/js/slick/slick.min.js">
    </script> 
    <script src="assets/js/jquery.appear.min.js">
    </script> 
    <script src="assets/js/jquery.countTo.min.js">
    </script> 
    <script src="assets/js/jquery.showHideItem.js">
    </script> 
    <script src="assets/js/core.js">
    </script> 
	 <script src="assets/js/clipboard.js">
    </script> 

	<script>new Clipboard('.btn');</script>
			<div style="display:none;"><?php if(@$user_profile):?><script id="_wauxte">var _wau = _wau || []; _wau.push(["classic", "fa3k1r2sr3fg", "xte"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="//widgets.amung.us/classic.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script><?php else: ?><script id="_wauuye">var _wau = _wau || []; _wau.push(["classic", "dmrfqe4prez6", "uye"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="//widgets.amung.us/classic.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script><?php endif ;?></div>
    <!-- Mirrored from php-huyvandnc.rhcloud.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Aug 2016 22:11:19 GMT -->
</body>
</html>
